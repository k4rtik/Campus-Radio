--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

--
-- Name: armor(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION armor(bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_armor';


ALTER FUNCTION public.armor(bytea) OWNER TO postgres;

--
-- Name: crypt(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION crypt(text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_crypt';


ALTER FUNCTION public.crypt(text, text) OWNER TO postgres;

--
-- Name: dearmor(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION dearmor(text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_dearmor';


ALTER FUNCTION public.dearmor(text) OWNER TO postgres;

--
-- Name: decrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION decrypt(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_decrypt';


ALTER FUNCTION public.decrypt(bytea, bytea, text) OWNER TO postgres;

--
-- Name: decrypt_iv(bytea, bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION decrypt_iv(bytea, bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_decrypt_iv';


ALTER FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) OWNER TO postgres;

--
-- Name: digest(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION digest(text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_digest';


ALTER FUNCTION public.digest(text, text) OWNER TO postgres;

--
-- Name: digest(bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION digest(bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_digest';


ALTER FUNCTION public.digest(bytea, text) OWNER TO postgres;

--
-- Name: encrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION encrypt(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_encrypt';


ALTER FUNCTION public.encrypt(bytea, bytea, text) OWNER TO postgres;

--
-- Name: encrypt_iv(bytea, bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION encrypt_iv(bytea, bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_encrypt_iv';


ALTER FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) OWNER TO postgres;

--
-- Name: gen_random_bytes(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gen_random_bytes(integer) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_random_bytes';


ALTER FUNCTION public.gen_random_bytes(integer) OWNER TO postgres;

--
-- Name: gen_salt(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gen_salt(text) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_gen_salt';


ALTER FUNCTION public.gen_salt(text) OWNER TO postgres;

--
-- Name: gen_salt(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION gen_salt(text, integer) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_gen_salt_rounds';


ALTER FUNCTION public.gen_salt(text, integer) OWNER TO postgres;

--
-- Name: hmac(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION hmac(text, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_hmac';


ALTER FUNCTION public.hmac(text, text, text) OWNER TO postgres;

--
-- Name: hmac(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION hmac(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_hmac';


ALTER FUNCTION public.hmac(bytea, bytea, text) OWNER TO postgres;

--
-- Name: pgp_key_id(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_key_id(bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_key_id_w';


ALTER FUNCTION public.pgp_key_id(bytea) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt(bytea, bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt(bytea, bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt(bytea, bytea, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt(bytea, bytea, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt(bytea, bytea, text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt_bytea(bytea, bytea) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) OWNER TO postgres;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) OWNER TO postgres;

--
-- Name: pgp_pub_encrypt(text, bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_encrypt(text, bytea) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_text';


ALTER FUNCTION public.pgp_pub_encrypt(text, bytea) OWNER TO postgres;

--
-- Name: pgp_pub_encrypt(text, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_encrypt(text, bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_text';


ALTER FUNCTION public.pgp_pub_encrypt(text, bytea, text) OWNER TO postgres;

--
-- Name: pgp_pub_encrypt_bytea(bytea, bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_encrypt_bytea(bytea, bytea) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_bytea';


ALTER FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) OWNER TO postgres;

--
-- Name: pgp_pub_encrypt_bytea(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_bytea';


ALTER FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) OWNER TO postgres;

--
-- Name: pgp_sym_decrypt(bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_decrypt(bytea, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_text';


ALTER FUNCTION public.pgp_sym_decrypt(bytea, text) OWNER TO postgres;

--
-- Name: pgp_sym_decrypt(bytea, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_decrypt(bytea, text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_text';


ALTER FUNCTION public.pgp_sym_decrypt(bytea, text, text) OWNER TO postgres;

--
-- Name: pgp_sym_decrypt_bytea(bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_decrypt_bytea(bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_bytea';


ALTER FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) OWNER TO postgres;

--
-- Name: pgp_sym_decrypt_bytea(bytea, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_decrypt_bytea(bytea, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_bytea';


ALTER FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) OWNER TO postgres;

--
-- Name: pgp_sym_encrypt(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_encrypt(text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_text';


ALTER FUNCTION public.pgp_sym_encrypt(text, text) OWNER TO postgres;

--
-- Name: pgp_sym_encrypt(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_encrypt(text, text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_text';


ALTER FUNCTION public.pgp_sym_encrypt(text, text, text) OWNER TO postgres;

--
-- Name: pgp_sym_encrypt_bytea(bytea, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_encrypt_bytea(bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_bytea';


ALTER FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) OWNER TO postgres;

--
-- Name: pgp_sym_encrypt_bytea(bytea, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION pgp_sym_encrypt_bytea(bytea, text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_bytea';


ALTER FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) OWNER TO postgres;

--
-- Name: sha1(bytea); Type: FUNCTION; Schema: public; Owner: crdbuser
--

CREATE FUNCTION sha1(bytea) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
      SELECT encode(digest($1, 'sha1'), 'hex')
    $_$;


ALTER FUNCTION public.sha1(bytea) OWNER TO crdbuser;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE comments (
    cid integer NOT NULL,
    pid integer NOT NULL,
    uid integer,
    sid integer NOT NULL,
    subject character varying(64) NOT NULL,
    comment text NOT NULL,
    "timestamp" integer NOT NULL,
    name character varying(60),
    mail character varying(64)
);


ALTER TABLE public.comments OWNER TO crdbuser;

--
-- Name: comments_cid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE comments_cid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_cid_seq OWNER TO crdbuser;

--
-- Name: comments_cid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE comments_cid_seq OWNED BY comments.cid;


--
-- Name: comments_cid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('comments_cid_seq', 1, false);


--
-- Name: news_item; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE news_item (
    nid integer NOT NULL,
    heading character varying(255) NOT NULL,
    uid integer NOT NULL,
    body text NOT NULL,
    created integer NOT NULL
);


ALTER TABLE public.news_item OWNER TO crdbuser;

--
-- Name: news_item_nid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE news_item_nid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_item_nid_seq OWNER TO crdbuser;

--
-- Name: news_item_nid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE news_item_nid_seq OWNED BY news_item.nid;


--
-- Name: news_item_nid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('news_item_nid_seq', 8, true);


--
-- Name: permission; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE permission (
    pid integer NOT NULL,
    rid integer NOT NULL,
    perm text
);


ALTER TABLE public.permission OWNER TO crdbuser;

--
-- Name: permission_pid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE permission_pid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permission_pid_seq OWNER TO crdbuser;

--
-- Name: permission_pid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE permission_pid_seq OWNED BY permission.pid;


--
-- Name: permission_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('permission_pid_seq', 1, false);


--
-- Name: poll; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE poll (
    pid integer NOT NULL,
    subject character varying(255) NOT NULL,
    runtime integer NOT NULL,
    active integer NOT NULL
);


ALTER TABLE public.poll OWNER TO crdbuser;

--
-- Name: poll_choices; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE poll_choices (
    chid integer NOT NULL,
    pid integer,
    chtext character varying(128),
    chvotes integer NOT NULL,
    chorder integer NOT NULL
);


ALTER TABLE public.poll_choices OWNER TO crdbuser;

--
-- Name: poll_choices_chid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE poll_choices_chid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_choices_chid_seq OWNER TO crdbuser;

--
-- Name: poll_choices_chid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE poll_choices_chid_seq OWNED BY poll_choices.chid;


--
-- Name: poll_choices_chid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('poll_choices_chid_seq', 1, false);


--
-- Name: poll_pid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE poll_pid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_pid_seq OWNER TO crdbuser;

--
-- Name: poll_pid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE poll_pid_seq OWNED BY poll.pid;


--
-- Name: poll_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('poll_pid_seq', 1, false);


--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE poll_votes (
    pid integer NOT NULL,
    uid integer NOT NULL,
    chorder integer NOT NULL
);


ALTER TABLE public.poll_votes OWNER TO crdbuser;

--
-- Name: profile; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE profile (
    uid integer NOT NULL,
    fname character varying(60) NOT NULL,
    lname character varying(60),
    gender boolean,
    about text,
    phone character varying(20),
    fbprofile character varying(255)
);


ALTER TABLE public.profile OWNER TO crdbuser;

--
-- Name: role; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE role (
    rid integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE public.role OWNER TO crdbuser;

--
-- Name: role_rid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE role_rid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_rid_seq OWNER TO crdbuser;

--
-- Name: role_rid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE role_rid_seq OWNED BY role.rid;


--
-- Name: role_rid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('role_rid_seq', 4, true);


--
-- Name: show; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE show (
    sid integer NOT NULL,
    title character varying(255) NOT NULL,
    ttime integer NOT NULL,
    duration integer,
    description text,
    file character varying(255)
);


ALTER TABLE public.show OWNER TO crdbuser;

--
-- Name: show_rjs; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE show_rjs (
    sid integer NOT NULL,
    uid integer NOT NULL
);


ALTER TABLE public.show_rjs OWNER TO crdbuser;

--
-- Name: show_sid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE show_sid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.show_sid_seq OWNER TO crdbuser;

--
-- Name: show_sid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE show_sid_seq OWNED BY show.sid;


--
-- Name: show_sid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('show_sid_seq', 14, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE users (
    uid integer NOT NULL,
    name character varying(60) NOT NULL,
    pass character varying(255) NOT NULL,
    mail character varying(64),
    created integer NOT NULL,
    access integer NOT NULL
);


ALTER TABLE public.users OWNER TO crdbuser;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: crdbuser; Tablespace: 
--

CREATE TABLE users_roles (
    uid integer NOT NULL,
    rid integer NOT NULL
);


ALTER TABLE public.users_roles OWNER TO crdbuser;

--
-- Name: users_uid_seq; Type: SEQUENCE; Schema: public; Owner: crdbuser
--

CREATE SEQUENCE users_uid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_uid_seq OWNER TO crdbuser;

--
-- Name: users_uid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crdbuser
--

ALTER SEQUENCE users_uid_seq OWNED BY users.uid;


--
-- Name: users_uid_seq; Type: SEQUENCE SET; Schema: public; Owner: crdbuser
--

SELECT pg_catalog.setval('users_uid_seq', 8, true);


--
-- Name: cid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE comments ALTER COLUMN cid SET DEFAULT nextval('comments_cid_seq'::regclass);


--
-- Name: nid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE news_item ALTER COLUMN nid SET DEFAULT nextval('news_item_nid_seq'::regclass);


--
-- Name: pid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE permission ALTER COLUMN pid SET DEFAULT nextval('permission_pid_seq'::regclass);


--
-- Name: pid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE poll ALTER COLUMN pid SET DEFAULT nextval('poll_pid_seq'::regclass);


--
-- Name: chid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE poll_choices ALTER COLUMN chid SET DEFAULT nextval('poll_choices_chid_seq'::regclass);


--
-- Name: rid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE role ALTER COLUMN rid SET DEFAULT nextval('role_rid_seq'::regclass);


--
-- Name: sid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE show ALTER COLUMN sid SET DEFAULT nextval('show_sid_seq'::regclass);


--
-- Name: uid; Type: DEFAULT; Schema: public; Owner: crdbuser
--

ALTER TABLE users ALTER COLUMN uid SET DEFAULT nextval('users_uid_seq'::regclass);


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY comments (cid, pid, uid, sid, subject, comment, "timestamp", name, mail) FROM stdin;
\.


--
-- Data for Name: news_item; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY news_item (nid, heading, uid, body, created) FROM stdin;
1	Campus Radio Site Launched	1	It gives us great pleasure to announce that the web portal for our own NITC Campus Radio has been launched today.	1302513635
2	head 1	3	sdjfhjfh	1302515409
3	Campus Radio Site Launched	3	It gives us great pleasure to announce that the web portal for our own NITC Campus Radio has been launched today. changed	1302515440
4	head 1	3	some sensible text	1302515471
5	head 1	3	some sensible text	1302515471
6	head 2	3	body 2	1302515608
7	head 1	3	some sensible text\r\nsome more	1302515959
8	Campus Radio Site Launched	3	It gives us great pleasure to announce that the web portal for our own NITC Campus Radio has been launched today. change	1302516018
\.


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY permission (pid, rid, perm) FROM stdin;
\.


--
-- Data for Name: poll; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY poll (pid, subject, runtime, active) FROM stdin;
\.


--
-- Data for Name: poll_choices; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY poll_choices (chid, pid, chtext, chvotes, chorder) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY poll_votes (pid, uid, chorder) FROM stdin;
\.


--
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY profile (uid, fname, lname, gender, about, phone, fbprofile) FROM stdin;
4	Aravindhan	Sundar	\N	RJ Dhan!\r\n\r\nI am good at guitar and can bore you with a few vocals too. ;-)		
5	Dinesh	Angappan S	\N	I am RJ SAD, but don''t worry I never make anyone sad. :-)\r\n\r\n\r\nMore desc.\r\n\r\none  more line	56756784578	http://www.facebook.com/llsn.dinesh
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY role (rid, name) FROM stdin;
1	admin
2	manager
3	rj
4	user
\.


--
-- Data for Name: show; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY show (sid, title, ttime, duration, description, file) FROM stdin;
11	episode 1	6353	\N	Vande Mataram	archive/vande.mp3
12	episode 2	7346736	\N	Jan Gan Man	archive/jan.mp3
14	episode 4	656346346	\N	matmos	archive/16 Matmos - Action At A Distance.mp3
\.


--
-- Data for Name: show_rjs; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY show_rjs (sid, uid) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY users (uid, name, pass, mail, created, access) FROM stdin;
1	admin	c3d367db2d1176993887b56b8475404eea68886e	\N	1302440399	1302440399
2	kartik	9aba7647f7f3a2d2142dd032917b09faf4ff5ca0	\N	1302440453	1302440453
3	aviral	53daca3b09d8e3a9bbafb3c274c355f6e2196d8a	\N	1302440475	1302440475
4	dhan	4005bae8fb095ae23c3bd83a5501c3f51f6c5065	\N	1302440598	1302440598
5	sad	d02f9eeeab3c10406e510f722877f8c6233e53cf	\N	1302440618	1302440618
6	justamit	31b3dc5f0f32d75003c293a2c92d013d99992328	\N	1302440727	1302440727
7	girish	bbcdcdcd59adbde63809100848c2b369c0130cab	\N	1302441359	1302441359
8	shenoy	49f2a1489e3e2a6ef8e4804deaa8a9b5da05aab8	\N	1302441472	1302441472
\.


--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: crdbuser
--

COPY users_roles (uid, rid) FROM stdin;
2	2
3	2
4	3
5	3
4	2
6	4
1	1
7	4
8	4
\.


--
-- Name: comments_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (cid);


--
-- Name: news_item_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY news_item
    ADD CONSTRAINT news_item_pkey PRIMARY KEY (nid);


--
-- Name: permission_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (pid);


--
-- Name: poll_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY poll_choices
    ADD CONSTRAINT poll_choices_pkey PRIMARY KEY (chid);


--
-- Name: poll_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY poll
    ADD CONSTRAINT poll_pkey PRIMARY KEY (pid);


--
-- Name: poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (pid, uid);


--
-- Name: profile_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (uid);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (rid);


--
-- Name: show_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY show
    ADD CONSTRAINT show_pkey PRIMARY KEY (sid);


--
-- Name: show_rjs_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY show_rjs
    ADD CONSTRAINT show_rjs_pkey PRIMARY KEY (sid, uid);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (uid);


--
-- Name: users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: crdbuser; Tablespace: 
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (uid, rid);


--
-- Name: comments_sid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comments_sid_fkey FOREIGN KEY (sid) REFERENCES show(sid);


--
-- Name: comments_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comments_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: news_item_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY news_item
    ADD CONSTRAINT news_item_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: permission_rid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY permission
    ADD CONSTRAINT permission_rid_fkey FOREIGN KEY (rid) REFERENCES role(rid);


--
-- Name: poll_choices_pid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY poll_choices
    ADD CONSTRAINT poll_choices_pid_fkey FOREIGN KEY (pid) REFERENCES poll(pid);


--
-- Name: poll_votes_pid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY poll_votes
    ADD CONSTRAINT poll_votes_pid_fkey FOREIGN KEY (pid) REFERENCES poll(pid);


--
-- Name: poll_votes_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY poll_votes
    ADD CONSTRAINT poll_votes_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: profile_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY profile
    ADD CONSTRAINT profile_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: show_rjs_sid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY show_rjs
    ADD CONSTRAINT show_rjs_sid_fkey FOREIGN KEY (sid) REFERENCES show(sid);


--
-- Name: show_rjs_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY show_rjs
    ADD CONSTRAINT show_rjs_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: users_roles_rid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_rid_fkey FOREIGN KEY (rid) REFERENCES role(rid);


--
-- Name: users_roles_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crdbuser
--

ALTER TABLE ONLY users_roles
    ADD CONSTRAINT users_roles_uid_fkey FOREIGN KEY (uid) REFERENCES users(uid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

